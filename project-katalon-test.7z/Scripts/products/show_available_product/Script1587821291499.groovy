import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl(GlobalVariable.server_url)

WebUI.setText(findTestObject('login/input_Username_username'), 'admin')

WebUI.setText(findTestObject('login/input_Password_password'), 'admin')

WebUI.click(findTestObject('login/button_Login'))

WebUI.verifyElementPresent(findTestObject('all_product/h5_Garden'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/p_The garden which you can grow everything _43035b'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h6_Price is 2000000 THB'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h5_Banana'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/p_A good fruit with very cheap price'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h6_Price is 15000 THB'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h5_Orange'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/p_Nothing good about it'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h6_Price is 28000 THB'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h5_Papaya'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/p_Use for papaya salad'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h6_Price is 1200 THB'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h5_Rambutan'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/p_An expensive fruit from the sout'), 0)

WebUI.verifyElementPresent(findTestObject('all_product/h6_Price is 2000 THB'), 0)

WebUI.closeBrowser()


