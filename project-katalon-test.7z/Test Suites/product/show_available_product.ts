<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>show_available_product</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>6dade887-e284-4b7a-a168-6dd65ec9d586</testSuiteGuid>
   <testCaseLink>
      <guid>4f4771d2-9bb5-48d3-beaa-8cc44ebc0bd3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/products/show_available_product</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
