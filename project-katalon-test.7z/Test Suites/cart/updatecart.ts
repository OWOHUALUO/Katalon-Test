<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>updatecart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>43c477af-fd32-4e5b-ae3c-190873182b7a</testSuiteGuid>
   <testCaseLink>
      <guid>025d048e-ad0b-4ea0-afa9-b0ee74f8e1bb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/cart/addcart</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
