<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>updateprice</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>19b161bc-267d-4ce0-9ca8-2dc0679111c0</testSuiteGuid>
   <testCaseLink>
      <guid>3c807fc6-aeee-4e78-b6e6-8332395f823a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/cart/updateprice</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
